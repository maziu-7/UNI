var searchData=
[
  ['plazas_5flibres_88',['plazas_libres',['../class_estacion.html#adb31f7572d2ee40172038b0e0368f248',1,'Estacion']]],
  ['plazas_5ftotales_89',['plazas_totales',['../class_cjt__estaciones.html#adbef32388a14a9932436a81eae4abc84',1,'Cjt_estaciones']]]
];
