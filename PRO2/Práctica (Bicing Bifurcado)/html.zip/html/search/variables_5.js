var searchData=
[
  ['vbicis_100',['vbicis',['../class_bici.html#ac76b2ce9955995b0198842b23b909fbf',1,'Bici']]]
];
